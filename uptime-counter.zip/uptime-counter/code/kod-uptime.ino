#include <LiquidCrystal.h>

LiquidCrystal lcd(12, 11, 5, 4, 3, 2);

unsigned long startTime = 0;
unsigned long bootStart;

void setup() {
  lcd.begin(16, 2);

  bootStart = millis();

  lcd.clear();
}

void loop() {

  unsigned long currentTime = millis();

  // BOOT sekvence prvních 25 sekund
  if (currentTime - bootStart < 25000) {

    lcd.setCursor(0, 0);
    lcd.print("uptime: 0s    ");

    // loading animace
    int dots = (currentTime / 500) % 4;

    lcd.setCursor(0, 1);
    lcd.print("status: boot");

    for (int i = 0; i < dots; i++) {
      lcd.print(".");
    }

    // smazání zbytku řádku
    lcd.print("   ");

  } else {

    // spuštění uptime po bootu
    if (startTime == 0) {
      startTime = millis();
      lcd.clear();
    }

    // uptime v sekundách
    unsigned long uptime = (millis() - startTime) / 1000;

    lcd.setCursor(0, 0);
    lcd.print("uptime: ");
    lcd.print(uptime);
    lcd.print("s   ");

    lcd.setCursor(0, 1);
    lcd.print("status: running");
  }

  delay(100);
}